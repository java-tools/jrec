/* generated javascript */var skin = 'nsis';
var stylepath = '/mediawiki/skins';/* MediaWiki:Nsis */
